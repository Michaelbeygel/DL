import torch
from torch import Tensor, nn
from typing import Union, Sequence
from collections import defaultdict

ACTIVATIONS = {
    "relu": nn.ReLU,
    "tanh": nn.Tanh,
    "sigmoid": nn.Sigmoid,
    "softmax": nn.Softmax,
    "logsoftmax": nn.LogSoftmax,
    "lrelu": nn.LeakyReLU,
    "none": nn.Identity,
    None: nn.Identity,
}


# Default keyword arguments to pass to activation class constructors, e.g.
# activation_cls(**ACTIVATION_DEFAULT_KWARGS[name])
ACTIVATION_DEFAULT_KWARGS = defaultdict(
    dict,
    {
        ###
        "softmax": dict(dim=1),
        "logsoftmax": dict(dim=1),
    },
)


class MLP(nn.Module):
    """
    A general-purpose MLP.
    """

    def __init__(
        self, in_dim: int, dims: Sequence[int], nonlins: Sequence[Union[str, nn.Module]]
    ):
        """
        :param in_dim: Input dimension.
        :param dims: Hidden dimensions, including output dimension.
        :param nonlins: Non-linearities to apply after each one of the hidden
            dimensions.
            Can be either a sequence of strings which are keys in the ACTIVATIONS
            dict, or instances of nn.Module (e.g. an instance of nn.ReLU()).
            Length should match 'dims'.
        """
        assert len(nonlins) == len(dims)
        super().__init__()
        self.in_dim = in_dim
        self.out_dim = dims[-1]

        # TODO:
        #  - Initialize the layers according to the requested dimensions. Use
        #    either nn.Linear layers or create W, b tensors per layer and wrap them
        #    with nn.Parameter.
        #  - Either instantiate the activations based on their name or use the provided
        #    instances.
        # ====== YOUR CODE: ======
        
        # Create a list of nn.Linear modules, each with the given dimentions.
        self.hidden_layers = nn.ModuleList([nn.Linear(in_dim, dims[0], bias=True)])
        self.hidden_layers.extend([nn.Linear(dims[l-1], dims[l], bias=True) for l in range(1, len(dims))])

        # Check for the type of nonlins, initialize a list of the activations functions respectively.
        self.activations = nn.ModuleList()
        for nonlin in nonlins:
            if isinstance(nonlin, str):
                # nonlin is a string key, instantiate from ACTIVATIONS dict
                activation_cls = ACTIVATIONS[nonlin]
                activation_kwargs = ACTIVATION_DEFAULT_KWARGS[nonlin]
                self.activations.append(activation_cls(**activation_kwargs))
            else:
                # nonlin is already an nn.Module instance, use it directly
                self.activations.append(nonlin)

        # ========================

    def forward(self, x: Tensor) -> Tensor:
        """
        :param x: An input tensor, of shape (N, D) containing N samples with D features.
        :return: An output tensor of shape (N, D_out) where D_out is the output dim.
        """
        # TODO: Implement the model's forward pass. Make sure the input and output
        #  shapes are as expected.
        # ====== YOUR CODE: ======
        
        # Make sure the input shape is as expected.
        assert x.shape[1] == self.in_dim

        # Apply hidden layers and activations in a loop throught the MLP.
        for hiddenLayer,activation in zip(self.hidden_layers, self.activations):
            x = activation(hiddenLayer(x))

        # Make sure the output shape is as expected.
        assert x.shape[1] == self.out_dim

        # Return x after it has been through the MLP.
        return x
        # ========================
