import numpy as np
import sklearn
from pandas import DataFrame
from typing import List
from sklearn.base import BaseEstimator, RegressorMixin, TransformerMixin
from sklearn.utils import check_array
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import PolynomialFeatures
from sklearn.utils.validation import check_X_y, check_is_fitted
from sklearn.model_selection import GridSearchCV


class LinearRegressor(BaseEstimator, RegressorMixin):
    """
    Implements Linear Regression prediction and closed-form parameter fitting.
    """

    def __init__(self, reg_lambda=0.1):
        self.reg_lambda = reg_lambda

    def predict(self, X):
        """
        Predict the class of a batch of samples based on the current weights.
        :param X: A tensor of shape (N,n_features_) where N is the batch size.
        :return:
            y_pred: np.ndarray of shape (N,) where each entry is the predicted
                value of the corresponding sample.
        """
        X = check_array(X)
        check_is_fitted(self, "weights_")

        # TODO: Calculate the model prediction, y_pred

        y_pred = X @ self.weights_
        
        return y_pred

    def fit(self, X, y):
        """
        Fit optimal weights to data using closed form solution.
        :param X: A tensor of shape (N,n_features_) where N is the batch size.
        :param y: A tensor of shape (N,) where N is the batch size.
        """
        X, y = check_X_y(X, y)

        # TODO:
        #  Calculate the optimal weights using the closed-form solution you derived.
        #  Use only numpy functions. Don't forget regularization!

        w_opt = None

        # We will assume the bias trick already applied(as happeneds in the pipeline)
        # Then the loss function is: 1/2N * |Xw-y|^2 + lambda/2 * |w|^2
        # The closed solution is therefore:
        # (X^T * X + I * N * lambda) * w = X^T * y
        # we will let numpy solve this for us, to ensure numerical stability

        N, D = X.shape

        # In order to avoid regularization of the bias that is embedded in the w vector from the bias trick,
        # we will change the identity matrix so that it will not include the weights that are responsible for b.
        # In this case, these weights are at the first indices.
        modified_identity_matrix = np.eye(D)
        modified_identity_matrix[0,0] = 0

        A = X.T @ X + modified_identity_matrix*N*self.reg_lambda
        B = X.T @ y
        # Solve for Aw=B  <->  (X^T * X + I * N * lambda) * w = X^T * y
        w_opt = np.linalg.solve(A, B)

        self.weights_ = w_opt
        return self

    def fit_predict(self, X, y):
        return self.fit(X, y).predict(X)


def fit_predict_dataframe(
    model, df: DataFrame, target_name: str, feature_names: List[str] = None,
):
    """
    Calculates model predictions on a dataframe, optionally with only a subset of
    the features (columns).
    :param model: An sklearn model. Must implement fit_predict().
    :param df: A dataframe. Columns are assumed to be features. One of the columns
        should be the target variable.
    :param target_name: Name of target variable.
    :param feature_names: Names of features to use. Can be None, in which case all
        features are used.
    :return: A vector of predictions, y_pred.
    """
    # TODO: Implement according to the docstring description.
    
    # If the list is empty, take the whole dataset
    if feature_names is None:
        part_of_df = df.drop(columns=[target_name])
    else:
        part_of_df = df[feature_names]

    y_pred = model.fit_predict(part_of_df, df[target_name])
    return y_pred


class BiasTrickTransformer(BaseEstimator, TransformerMixin):
    def fit(self, X, y=None):
        return self

    def transform(self, X: np.ndarray):
        """
        :param X: A tensor of shape (N,D) where N is the batch size and D is
        the number of features.
        :returns: A tensor xb of shape (N,D+1) where xb[:, 0] == 1
        """
        X = check_array(X, ensure_2d=True)

        # TODO:
        #  Add bias term to X as the first feature.
        #  See np.hstack().

        # Create a ndarray bias column
        bias_column = np.full((X.shape[0],1),1)

        # Concat the two ndarrays
        xb = np.hstack((bias_column,X))

        return xb


class BostonFeaturesTransformer(BaseEstimator, TransformerMixin):
    """
    Generates custom features for the Boston dataset.
    """

    def __init__(self, degree=2):
        self.degree = degree

        # TODO: Your custom initialization, if needed
        # Add any hyperparameters you need and save them as above

        # Added polynomial transformer feature
        self.poly_transform = PolynomialFeatures(self.degree)

    def fit(self, X, y=None):
        CHAS_index = 3
        X_transformed = np.delete(X, CHAS_index, 1)
        self.poly_transform.fit(X_transformed)
        return self

    def transform(self, X):
        """
        Transform features to new features matrix.
        :param X: Matrix of shape (n_samples, n_features_).
        :returns: Matrix of shape (n_samples, n_output_features_).
        """
        X = check_array(X)

        # TODO:
        #  Transform the features of X into new features in X_transformed
        #  Note: You CAN count on the order of features in the Boston dataset
        #  (this class is "Boston-specific"). For example X[:,1] is the second
        #  feature ('ZN').

        # Copy the dataframe. Make sure the datatype is float for the log operations
        X_transformed = X.copy().astype(float)
        # Apply log function to CRIM, and then to LSTAT
        CRIM_index = 0
        LSTAT_index = 12
        X_transformed[:,CRIM_index] = np.log1p(X_transformed[:,CRIM_index])
        X_transformed[:,LSTAT_index] = np.log1p(X_transformed[:,LSTAT_index])
        # Remove CHAS feature
        CHAS_index = 3
        X_transformed = np.delete(X_transformed, CHAS_index, 1)

        # Increase the model capacity by adding parameters
        X_transformed = self.poly_transform.transform(X_transformed)

        return X_transformed


def top_correlated_features(df: DataFrame, target_feature, n=5):
    """
    Returns the names of features most strongly correlated (correlation is
    close to 1 or -1) with a target feature. Correlation is Pearson's-r sense.

    :param df: A pandas dataframe.
    :param target_feature: The name of the target feature.
    :param n: Number of top features to return.
    :return: A tuple of
        - top_n_features: Sequence of the top feature names
        - top_n_corr: Sequence of correlation coefficients of above features
        Both the returned sequences should be sorted so that the best (most
        correlated) feature is first.
    """

    # TODO: Calculate correlations with target and sort features by it

    # Calculates correlation matrix
    correlation_df = df.corr(method="pearson")

    # Choose the column for the target_feature, get the absolute values, sort it,
    # then get the top n elements(excluding the first element, which is the correlation of
    # the target_feature with itself)
    top_n_corr = correlation_df[target_feature].abs().sort_values(ascending=False)[1:n+1]

    # Return the names of the top indices
    top_n_features = top_n_corr.index.tolist()

    return top_n_features, top_n_corr


def mse_score(y: np.ndarray, y_pred: np.ndarray):
    """
    Computes Mean Squared Error.
    :param y: Predictions, shape (N,)
    :param y_pred: Ground truth labels, shape (N,)
    :return: MSE score.
    """

    # TODO: Implement MSE using numpy.

    mse = ((y-y_pred)**2).mean(axis=0)

    return mse


def r2_score(y: np.ndarray, y_pred: np.ndarray):
    """
    Computes R^2 score,
    :param y: Predictions, shape (N,)
    :param y_pred: Ground truth labels, shape (N,)
    :return: R^2 score.
    """

    # TODO: Implement R^2 using numpy.

    prediction_residuals_squared_sum = ((y-y_pred)**2).sum()

    average_residuals_squared_sum = ((y-y.mean(axis=0))**2).sum()

    # Check edge case of division by 0
    if average_residuals_squared_sum == 0:
        return 0.0

    r2 = 1 - (prediction_residuals_squared_sum/average_residuals_squared_sum)

    return r2


def cv_best_hyperparams(
    model: BaseEstimator, X, y, k_folds, degree_range, lambda_range
):
    """
    Cross-validate to find best hyperparameters with k-fold CV.
    :param X: Training data.
    :param y: Training targets.
    :param model: sklearn model.
    :param lambda_range: Range of values for the regularization hyperparam.
    :param degree_range: Range of values for the degree hyperparam.
    :param k_folds: Number of folds for splitting the training data into.
    :return: A dict containing the best model parameters,
        with some of the keys as returned by model.get_params()
    """

    # TODO: Do K-fold cross validation to find the best hyperparameters
    #  Notes:
    #  - You can implement it yourself or use the built in sklearn utilities
    #    (recommended). See the docs for the sklearn.model_selection package
    #    http://scikit-learn.org/stable/modules/classes.html#module-sklearn.model_selection
    #  - If your model has more hyperparameters (not just lambda and degree)
    #    you should add them to the search.
    #  - Use get_params() on your model to see what hyperparameters is has
    #    and their names. The parameters dict you return should use the same
    #    names as keys.
    #  - You can use MSE or R^2 as a score.

    param_grid = [{
        'bostonfeaturestransformer__degree': degree_range, 
        'linearregressor__reg_lambda': lambda_range
    }]

    grid_search = GridSearchCV(model, param_grid, cv=k_folds, scoring='r2')
    grid_search.fit(X,y)

    best_params = grid_search.best_params_
    return best_params
